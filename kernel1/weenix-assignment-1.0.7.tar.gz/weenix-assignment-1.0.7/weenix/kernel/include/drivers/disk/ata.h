#pragma once

/**
 * Initialize the ATA subsystem.
 */
void ata_init(void);
