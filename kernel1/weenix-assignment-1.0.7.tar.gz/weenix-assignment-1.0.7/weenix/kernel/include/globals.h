#pragma once

#include "proc/kthread.h"
#include "proc/proc.h"

extern kthread_t *curthr;
extern proc_t *curproc;
