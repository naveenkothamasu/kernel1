#pragma once

struct mmobj;

void shadow_init();
struct mmobj *shadow_create(void);

extern int shadow_count;

