#pragma once

void shadowd_wakeup(void);
void shadowd_alloc_sleep(void);
