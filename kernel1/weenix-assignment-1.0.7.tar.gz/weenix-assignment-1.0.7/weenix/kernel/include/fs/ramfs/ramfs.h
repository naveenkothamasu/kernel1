
#pragma once

#include "fs/vfs.h"

int ramfs_mount(struct fs *fs);
