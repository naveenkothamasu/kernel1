#ifndef __S5FS_PRIVTEST_H
#define __S5FS_PRIVTEST_H

int s5fs_start(const char *testroot);

#endif
